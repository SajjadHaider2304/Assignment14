import "../node_modules/bootstrap/dist/css/bootstrap.min.css"
import "../src/assests/style.css"

import Navbar from "./Compounents/navBar/Navbar";
import HeroSection from "./Compounents/heroSection/HeroSection";
import Reputation from "./Compounents/reputation/Reputation"
import AboutUs from "./Compounents/aboutus/AboutUs"
import Services from "./Compounents/services/Services";
import Experience from "./Compounents/experience/Experience";
import Consultation from "./Compounents/consultation/Consultation";
import Projects from "./Compounents/projectssection/Projects"
import Contact from "./Compounents/contact/Contact";
import Footer from "./Compounents/footer/Footer";


function App() {
  return (
    <>
      <Navbar/>
      <HeroSection/>
      <Reputation/>
      <AboutUs/>
      <Services/>
      <Experience/>
      <Consultation/>
      <Projects/>
      <Contact/>
      <Footer/>
    </>
  );
}

export default App;
