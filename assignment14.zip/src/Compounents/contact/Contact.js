import "./Contact.css"

export default function Contact() {
    return (
        <>
            <div className="container-fluid p-4 colorback">
                <div className="row">
                    <div className="col-lg-6 mx-auto">
                        <form className="col-md-9 m-auto" method="post" role="form">
                            <h2 className="text-center   ">What can us do for you?</h2>
                            <p className="text-center mb-5  ">We are ready to work on a Project of any complexity <br/>whether it's commercial or residential. </p>
                            <div className="row">
                                <div className="form-group col-md-6 mb-3">
                                  
                                    <input type="text" className="form-control mt-1" id="name" name="name" placeholder="You Name"/>
                                </div>
                                <div className="form-group col-md-6 mb-3">
                                 
                                    <input type="email" className="form-control mt-1" id="email" name="email" placeholder="Email"/>
                                </div>
                            </div>
                            <div className="row">
                                <div className="form-group col-md-6 mb-3">
                                  
                                    <input type="text" className="form-control mt-1" id="name" name="name" placeholder="Reasons for Contacting"/>
                                </div>
                                <div className="form-group col-md-6 mb-3">
                                   
                                    <input type="phone" className="form-control mt-1" id="email" name="email" placeholder="Phone"/>
                                </div>
                            </div>
                             
                            <div className="mb-3">
                                
                                <textarea className="form-control mt-1" id="message" name="message" placeholder="Message" rows="8"></textarea>
                            </div>
                            <div className="row">
                                <div className="col text-end mt-2">
                                    <button  className="btn btn-primary btn-lg px-3 float-right">Submit</button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </>
    )
}
